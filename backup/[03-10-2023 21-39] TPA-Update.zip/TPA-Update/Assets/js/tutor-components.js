const accordionBtns = document.querySelectorAll(".accordion");
