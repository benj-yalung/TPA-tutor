import { TabInterface } from "../shared/tabInterface.js";


new TabInterface("[data-target='tabsSelection']", "[data-target='tabsChoice']", "[data-target='tabsContent']")