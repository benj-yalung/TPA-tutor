

export const element = el => document.querySelector(el)

export const elements = el => document.querySelectorAll(el)